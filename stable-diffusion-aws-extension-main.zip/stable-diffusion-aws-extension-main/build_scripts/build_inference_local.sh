#!/usr/bin/env bash

./build_and_push_local.sh Dockerfile.inference.from_scratch esd-inference dev "dev"
