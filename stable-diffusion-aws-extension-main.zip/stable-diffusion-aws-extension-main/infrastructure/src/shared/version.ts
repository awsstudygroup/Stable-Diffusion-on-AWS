// this const will be rewritten by the release pipeline
// keep one const here for ts to compile
export const ESD_VERSION: string = 'dev';
