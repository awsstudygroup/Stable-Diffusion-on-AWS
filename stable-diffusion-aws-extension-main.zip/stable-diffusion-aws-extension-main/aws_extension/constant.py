from enum import Enum

class MODEL_TYPE(Enum):
    EMBEDDING = "embedding"
    LORA = "lora"
    HYPER_NETWORK = "hypernetwork"
