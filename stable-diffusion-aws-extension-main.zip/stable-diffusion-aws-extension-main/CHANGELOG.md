`Updated：2023-06-20`

| Date  | Description |
|----------|--------|
| 2023-06 | **Release 1.0.0** <br> supported extension <ol><li>Dreambooth</li><li>Controlnet</li><li>Txt2img</li></ol> |

