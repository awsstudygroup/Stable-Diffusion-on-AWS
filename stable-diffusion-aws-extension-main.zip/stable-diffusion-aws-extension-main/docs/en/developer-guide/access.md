The API is open to the public network and the type is `REGIONAL` by default. 

If you want to restrict access to the API, you can set `ApiEndpointType` to `PRIVATE`.

You can link VpcEndpoint to the API by setting `VpcEndpointIds` to the VPC endpoint ID.
