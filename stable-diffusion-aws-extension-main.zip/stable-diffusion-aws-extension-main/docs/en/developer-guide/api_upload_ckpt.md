### Upload through URL
- Request `CreateCheckpoint`

### Upload through file
- Request `CreateCheckpoint` to create a model file
- Upload files through S3 pre signed address
- Update status through `UpdateCheckpoint`
