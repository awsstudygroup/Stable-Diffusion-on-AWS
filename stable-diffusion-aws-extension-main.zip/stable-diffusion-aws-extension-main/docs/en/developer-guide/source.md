Visit our GitHub repository to download the templates and scripts for this solution. The Extension for Stable Diffusion on AWS template is generated using the [AWS Cloud Development Kit (CDK)](http://aws.amazon.com/cdk/){:target="_blank"}. Refer to the README.md file for additional information.


