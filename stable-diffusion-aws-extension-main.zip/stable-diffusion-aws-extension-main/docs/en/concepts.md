This section describes key concepts and defines terminology specific to this solution: 


