<Use case 1 definition>


