To automated deployment, this solution uses the following AWS CloudFormation templates, which you can download before deployment:

 [xxx.template]: Use this template to launch the solution and all associated components. The default configuration deploys [Amazon API Gateway][api-gateway], [Amazon Lambda][lambda], [Amazon Batch][Batch], [Amazon S3][s3], [Amazon EFS][efs] and [Amazon Batch][Batch], but you can customize the template to meet your specific needs.

