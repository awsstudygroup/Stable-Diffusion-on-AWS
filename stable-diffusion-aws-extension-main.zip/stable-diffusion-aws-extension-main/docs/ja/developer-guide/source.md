このソリューションのテンプレートとスクリプトをダウンロードするには、GitHub リポジトリをご覧ください。
Extension for Stable Diffusion on AWS のテンプレートは、[AWS Cloud Development Kit (CDK)](http://aws.amazon.com/cdk/) を使って生成されています。
詳細については、README.md ファイルをご参照ください。
