API はパブリックネットワークに対して開放され、デフォルトではタイプは `REGIONAL` である。

APIへのアクセスを制限する場合は、`ApiEndpointType` を `PRIVATE` に設定します。

`VpcEndpointIds` を設定することで、`VpcEndpoint` をAPIにリンクすることができます。
