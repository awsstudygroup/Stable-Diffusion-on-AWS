# 在comfyUI上管理Custom Nodes



您可以打开**txt2img**标签页，通过结合使用**txt2img**原生区域及解决方案新增面板**Amazon SageMaker Inference**，实现调用云上资源的**txt2img**推理工作。 


## txt2img的使用方法
### 通用场景
