API 对公共网络开放，默认情况下类型为 `REGIONAL` 。

如果要限制对 API 的访问，可以将 `ApiEndpointType` 设置为 `PRIVATE`。

您可以通过将 `VpcEndpointIds` 设置为将 `VpcEndpoint` 链接到 API。
